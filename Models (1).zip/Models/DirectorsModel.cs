﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class DirectorsModel
    {
        public int ActorNumber { get; set; }

        public string DirectorFirstName { get; set; }
        
        public string DirectorLastName { get; set; }


    }
}