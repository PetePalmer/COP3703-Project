﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class CustomerBalancesModel
    {
        public string Username { get; set; }

        public float OutstandingRentalFees { get; set; }

        public float StoreCredit { get; set; }

        public string EmployeeDiscount { get; set; }
    }
}