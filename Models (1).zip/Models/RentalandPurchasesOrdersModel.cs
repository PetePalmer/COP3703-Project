﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class RentalandPurchasesOrdersModel
    {
        public int TransactiondID { get; set; }

        public int Username { get; set; }

        public int RentedMovies { get; set; }

        public int PurchasedMovies { get; set; }

        public float TransactionTotal { get; set; }

        public DateTime RentalDueDates { get; set; }

        public DateTime ReturnedDate { get; set; }

        public DateTime OrderDate { get; set; }
    }
}