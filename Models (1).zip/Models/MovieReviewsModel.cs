﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class MovieReviewsModel
    {
        public int ReviewID { get; set; }

        public int MovideId { get; set; }

        public string Username { get; set; }

        public int Review { get; set; }

        public string WrittenReview { get; set; }


    }
}