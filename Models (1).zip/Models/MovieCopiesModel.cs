﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class MovieCopiesModel
    {
        public int CopyID { get; set; }

        public int MovieID { get; set; }

        public string NewRelease { get; set; }

        public float Price { get; set; }

        public string CurrentlyRented {get;set;}

        public DateTime DueDate { get; set; }

        public string UsedCondition { get; set; }




    }
}