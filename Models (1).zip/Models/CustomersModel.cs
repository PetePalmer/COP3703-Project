﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class CustomersModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public string Name { get; set; }

        public DateTime DOB { get; set; }

        public int PhoneNumber { get; set; }

        public int Email { get; set; }

        public string MostLikedGenre { get; set; }

        public string SecondMostLikedGenre { get; set; }

        public string MostViewedActor { get; set; }
    }
}