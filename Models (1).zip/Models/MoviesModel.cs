﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class MoviesModel
    {
        public int MovieID { get; set; }

        public int NumberOfCopies { get; set; }

        public int CopiesCurrentlyRented { get; set; }

        public string Genre { get; set; }

        public float AverageUserReview { get; set; }

        public int NumberUserReview { get; set; }

        public string MPAARating { get; set; }

        public DateTime ReleaseDate { get; set; }

        public string Actor { get; set; }

        public string MainActor { get; set; }

        public string SupportingActor { get; set; }

        public int Runtime { get; set; }

        public string Description { get; set; }

        public string NewRelease { get; set; }
    }
}