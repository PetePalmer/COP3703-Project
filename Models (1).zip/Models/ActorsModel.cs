﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UNFMoviesProject.Models
{
    public class ActorsModel
    {
        public int ActorID { get; set; }
        public string ActorFirstName { get; set; }
        public string ActorLastName { get; set; }

}